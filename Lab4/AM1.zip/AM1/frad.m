function x=frad(degrees);
%degrees to rad
x=degrees*pi/180.0;
